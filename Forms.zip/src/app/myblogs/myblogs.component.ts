import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-myblogs',
  templateUrl: './myblogs.component.html',
  styleUrls: ['./myblogs.component.css']
})
export class MyblogsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
